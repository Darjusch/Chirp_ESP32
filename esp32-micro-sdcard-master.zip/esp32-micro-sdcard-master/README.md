visit IOTSHARING.COM for more
# esp32_nanosdcard
this library is for Arduino, I modified it to adapt with ESP32

Demo 7: How to use Arduino ESP32 to store data to sdcard
http://www.iotsharing.com/2017/05/how-to-use-arduino-esp32-to-store-data-to-sdcard.html
